package controllers;

import java.util.List;
import models.Medico;
import models.Especialidade;
import models.Status;
import play.mvc.Controller;

public class Medicos extends Controller {

	// Exibe o formulário de cadastro ou edição
	public static void form(Long id) {
		Medico med = null;
		if (id != null) {
			med = Medico.findById(id);
		}
		List<Especialidade> especialidades = Especialidade.findAll();
		render(med, especialidades);
	}

	// Salva ou atualiza médico
	public static void salvar(Medico med) {
		if (med.id != null) {
			med = med.merge(); // Atualiza se já existir
		} else {
			med.status = Status.ATIVO; // Define status ao criar
			med.save();
		}
		listar(null);
	}

	// Lista médicos ativos, com busca opcional
	public static void listar(String termo) {
		List<Medico> medicosAtivos;

		if (termo != null && !termo.trim().isEmpty()) {
			medicosAtivos = Medico.find("(lower(nome) like ?1 or lower(email) like ?1) and status <> ?2",
					"%" + termo.toLowerCase() + "%", Status.INATIVO).fetch();
		} else {
			medicosAtivos = Medico.find("status <> ?1", Status.INATIVO).fetch();
		}

		render(medicosAtivos, termo);
	}

	// Excluir médico (opcional)
	public static void excluir(Long id) {
		Medico med = Medico.findById(id);
		if (med != null) {
			med.status = Status.INATIVO; // Marca como inativo
			med.save();
		}
		listar(null);
	}
}
