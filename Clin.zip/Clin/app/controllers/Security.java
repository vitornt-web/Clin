package controllers;

import play.mvc.Before;
import play.mvc.Controller;

public class Security extends Controller {

    @Before
    static void verificarLogin() {
        if (!session.contains("usuario")) {
            flash.error("Você precisa estar logado para acessar esta página.");
            Logins.form();
        }
    }
}
