package controllers;

import play.mvc.Controller;

public class Logins extends Controller {

	public static void form() {
		render("Medicos/login.html");
	}

	public static void autenticar(String usuario, String senha) {
		if ("admin".equals(usuario) && "123".equals(senha)) {
			session.put("usuario", usuario);
			flash.success("Login realizado com sucesso!");
			Application.index();
		} else {
			flash.error("Usuário ou senha inválidos!");
			form();
		}
	}

	public static void sair() {
		session.clear();
		flash.success("Você saiu do sistema.");
		form();
	}
}
